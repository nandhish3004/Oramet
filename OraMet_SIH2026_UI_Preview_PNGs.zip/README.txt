OraMet SIH 2026 — illustrative UI preview images

This folder contains 15 PNG illustrations covering the app's 15 navigation routes, plus a contact sheet. The screen images are source-based UI previews, not screenshots captured from a running Android device or emulator. Individual PNGs are 860 x 1864.

Use the individual numbered PNGs for presentation slides. Keep the “ILLUSTRATIVE UI PREVIEW · NOT A DEVICE CAPTURE” footer visible and do not describe them as actual screenshots.
